// package org.firstinspires.ftc.teamcode;

// import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.hardware.Servo;

// @TeleOp(name = "HermelaJoystick (Blocks to Java)")
// public class HermelaJoystick extends LinearOpMode {

//   private DcMotor backleftMotor;
//   private DcMotor backrightMotor;
//   private DcMotor elbow;
//   private Servo claw;
//   private Servo wrist;
// }

