package org.firstinspires.ftc.teamcode;

import android.transition.Slide;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.TouchSensor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

@TeleOp
public class BabyTeleop extends LinearOpMode{
    
    @Override
    public void runOpMode() {
        DcMotor fl = hardwareMap.get(DcMotor.class, "fl");
        DcMotor fr = hardwareMap.get(DcMotor.class, "fr");
        DcMotor bl = hardwareMap.get(DcMotor.class, "bl");
        DcMotor br = hardwareMap.get(DcMotor.class, "br");
        Servo arm = hardwareMap.get(Servo.class, "arm");
        Servo claw = hardwareMap.get(Servo.class, "claw");

        fr.setDirection(DcMotorSimple.Direction.REVERSE);
        bl.setDirection(DcMotorSimple.Direction.REVERSE);
        arm.setDirection(Servo.Direction.REVERSE);

        fr.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        fl.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        br.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        bl.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        
        waitForStart();
        
        while (opModeIsActive()) {
            double y = gamepad1.right_stick_y;
            double x = gamepad1.right_stick_x;
            double rx = -gamepad1.left_stick_x;
            fr.setPower(((-y) + x - rx) * 0.6);
            br.setPower((y + x + rx) * 0.6);
            fl.setPower(((-y) - x + rx) * 0.6);
            bl.setPower((y - x - rx) * 0.6);
            if (gamepad1.left_trigger > 0.7) {
                arm.setPosition(0.6);
                telemetry.addData("arm", arm.getPosition());
                telemetry.addData("claw", claw.getPosition());
                telemetry.update();
            }
            if (gamepad1.right_trigger > 0.7) {
                arm.setPosition(0.3);
                telemetry.addData("arm", arm.getPosition());
                telemetry.addData("claw", claw.getPosition());
                telemetry.update();
            }
            if (gamepad1.y) {
                arm.setPosition(0.23);
                telemetry.addData("arm", arm.getPosition());
                telemetry.addData("claw", claw.getPosition());
                telemetry.update();
            }
            if (gamepad1.left_bumper) {
                int weirdo = 1;
                if (weirdo == 1) {
                    claw.setPosition(0.5);
                } else {
                    weirdo = 0;   
                }
            }
            if (gamepad1.right_bumper) {
                int weirdo2 = 1;
                if (weirdo2 == 1) {
                    claw.setPosition(1);
                } else {
                    weirdo2 = 0;   
                }
            }
            
            // telemetry.addData("arm", arm.getPosition());
            // telemetry.addData("claw", claw.getPosition());
            // telemetry.update();
        }
        
    }
}