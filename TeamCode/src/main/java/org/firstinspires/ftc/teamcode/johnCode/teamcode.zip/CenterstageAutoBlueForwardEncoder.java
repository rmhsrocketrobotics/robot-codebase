package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import org.firstinspires.ftc.robotcore.external.JavaUtil;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import com.qualcomm.robotcore.hardware.CRServo;

@Autonomous(name = "BlueForwardEncoder")
public class CenterstageAutoBlueForwardEncoder extends LinearOpMode {
    
    DcMotor fl;
        DcMotor fr;
        DcMotor bl;
        DcMotor br;
        DistanceSensor left_sensor;
        DistanceSensor right_sensor;
        //Servo arm;
        Servo ra;
        Servo la;
        Servo pincher;
        DcMotor rs;
        DcMotor ls;
        DcMotor belt;
        
        public void reset() {
        fl.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        fr.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        bl.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        br.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    }
        
    public void run() {
        fl.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        fr.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        bl.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        br.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        while(fl.isBusy());
    }

    @Override
    public void runOpMode() {
        
        double left_sensor1 = 0;
        double right_sensor1 = 0;
        double test = 0;
        
        fl = hardwareMap.get(DcMotor.class, "fl");
        fr = hardwareMap.get(DcMotor.class, "fr");
        bl = hardwareMap.get(DcMotor.class, "bl");
        br = hardwareMap.get(DcMotor.class, "br");
        left_sensor = hardwareMap.get(DistanceSensor.class, "left_sensor");
        right_sensor = hardwareMap.get(DistanceSensor.class, "right_sensor");
        //arm = hardwareMap.get(Servo.class, "arm");
        la = hardwareMap.get(Servo.class, "la");
        ra = hardwareMap.get(Servo.class, "ra");
        pincher = hardwareMap.get(Servo.class, "pincher");
        rs = hardwareMap.get(DcMotor.class, "rs");
        ls = hardwareMap.get(DcMotor.class, "ls");
        belt = hardwareMap.get(DcMotor.class, "belt");
        
        ra.setDirection(Servo.Direction.REVERSE);
        fr.setDirection(DcMotorSimple.Direction.REVERSE);
        br.setDirection(DcMotorSimple.Direction.REVERSE);
        belt.setDirection(DcMotorSimple.Direction.REVERSE);
        rs.setDirection(DcMotorSimple.Direction.REVERSE);
        fr.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        fl.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        br.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        bl.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rs.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        ls.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        
        telemetry.addData("beforedistanceright", right_sensor.getDistance(DistanceUnit.INCH));
        telemetry.addData("beforedistanceleft", right_sensor.getDistance(DistanceUnit.INCH));
        telemetry.update();
        
        fl.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        fr.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        bl.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        br.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        fl.setTargetPosition(0);
        fr.setTargetPosition(0);
        bl.setTargetPosition(0);
        br.setTargetPosition(0);

        fl.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        fr.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        bl.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        br.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        
        fl.setPower(0.4);
        fr.setPower(0.4);
        bl.setPower(0.4);
        br.setPower(0.4);

        waitForStart();

        telemetry.addData("leftdistance", left_sensor.getDistance(DistanceUnit.INCH));
        telemetry.addData("rightdistane", right_sensor.getDistance(DistanceUnit.INCH));
        telemetry.update();
        
        pincher.setPosition(1);
        
        reset();
        fl.setTargetPosition(160);
        fr.setTargetPosition(160);
        bl.setTargetPosition(160);
        br.setTargetPosition(160);
        run();
        
        //sleep(300);
        
        reset();
        fl.setTargetPosition(180);
        fr.setTargetPosition(-180);
        bl.setTargetPosition(-180);
        br.setTargetPosition(180);
        run();
        
        //sleep(300);
        
        reset();
        fl.setTargetPosition(700);
        fr.setTargetPosition(700);
        bl.setTargetPosition(700);
        br.setTargetPosition(700);
        run();
        
        sleep(200);

        reset();
        fl.setTargetPosition(730);
        fr.setTargetPosition(730);
        bl.setTargetPosition(730);
        br.setTargetPosition(730);
        run();

        right_sensor1 = right_sensor.getDistance(DistanceUnit.INCH);
        left_sensor1 = left_sensor.getDistance(DistanceUnit.INCH);
        telemetry.addData("leftdistancer", left_sensor.getDistance(DistanceUnit.INCH));
        telemetry.addData("rightdistancer", right_sensor.getDistance(DistanceUnit.INCH));
        sleep(100);

        if (left_sensor1 < 6 & test == 0) {
            
            fl.setPower(0.9);
            fr.setPower(0.9);
            bl.setPower(0.9);
            br.setPower(0.9);
            
            telemetry.addData("leftdistancer", left_sensor.getDistance(DistanceUnit.INCH));
            telemetry.addData("rightdistancer", right_sensor.getDistance(DistanceUnit.INCH));
            telemetry.addData("e", test);
            telemetry.update();
            
            reset();
            fl.setTargetPosition(-250);
            fr.setTargetPosition(-250);
            bl.setTargetPosition(-250);
            br.setTargetPosition(-250);
            run();
            
            
            //fl.setPower(0.3);
            //fr.setPower(-0.3);
            //bl.setPower(-0.3);
            //br.setPower(0.3);
            //sleep(500);
            
            reset();
            fl.setTargetPosition(-925);
            fr.setTargetPosition(925);
            bl.setTargetPosition(-925);
            br.setTargetPosition(925);
            run();
            
            reset();
            fl.setTargetPosition(340);
            fr.setTargetPosition(340);
            bl.setTargetPosition(340);
            br.setTargetPosition(340);
            run();
            
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(200);
            
            belt.setPower(1);
            rs.setPower(0);
            ls.setPower(0);
            sleep(750);
            
            belt.setPower(0);
            rs.setPower(0.5);
            ls.setPower(0.5);
            
            reset();
            fl.setTargetPosition(200);
            fr.setTargetPosition(200);
            bl.setTargetPosition(200);
            br.setTargetPosition(200);
            run();
            
            rs.setPower(0);
            ls.setPower(0);
            belt.setPower(0);
            
            reset();
            fl.setTargetPosition(-1200);
            fr.setTargetPosition(-1200);
            bl.setTargetPosition(-1200);
            br.setTargetPosition(-1200);
            run();
            
            reset();
            fl.setTargetPosition(-1750);
            fr.setTargetPosition(1750);
            bl.setTargetPosition(-1750);
            br.setTargetPosition(1750);
            run();
            
            sleep(150);
            
            reset();
            fl.setTargetPosition(800);
            fr.setTargetPosition(800);
            bl.setTargetPosition(800);
            br.setTargetPosition(800);
            run();
            
            // reset();
            // fl.setTargetPosition(350);
            // fr.setTargetPosition(-350);
            // bl.setTargetPosition(-350);
            // br.setTargetPosition(350);
            // run();
            
            sleep(150);
            
            reset();
            fl.setTargetPosition(200);
            fr.setTargetPosition(200);
            bl.setTargetPosition(200);
            br.setTargetPosition(200);
            run();
            
            // fl.setPower(-0.3);
            // fr.setPower(0.3);
            // bl.setPower(0.3);
            // br.setPower(-0.3);
            // sleep(935);
            
            //arm.setPosition(0.05);
            la.setPosition(0.38);
            ra.setPosition(0.87);
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(700);
            
            pincher.setPosition(0.5);
            rs.setPower(0);
            ls.setPower(0);
            sleep(1000);
            
            //fl.setPower(0.355);
            //fr.setPower(-0.3);
            //bl.setPower(0.3);
            //br.setPower(-0.3);
            //sleep(3000);
            
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(400);
            
            rs.setPower(0);
            ls.setPower(0);
            sleep(100);
            
            reset();
            fl.setTargetPosition(-600);
            fr.setTargetPosition(-600);
            bl.setTargetPosition(-600);
            br.setTargetPosition(-600);
            telemetry.addData("ticks", fl.getTargetPosition());
            telemetry.update();
            run();
            
            fl.setPower(0.9);
            fr.setPower(0.9);
            bl.setPower(0.9);
            br.setPower(0.9);
            
            reset();
            fl.setTargetPosition(-1650);
            fr.setTargetPosition(1650);
            bl.setTargetPosition(1650);
            br.setTargetPosition(-1650);
            run();
        
            ls.setPower(0.4);
            rs.setPower(0.4);
            //arm.setPosition(0.8);
            la.setPosition(0.12);
            ra.setPosition(0.61);
            //sleep(1600);
            
            reset();
            fl.setTargetPosition(800);
            fr.setTargetPosition(800);
            bl.setTargetPosition(800);
            br.setTargetPosition(800);
            run();
            
            rs.setPower(0);
            ls.setPower(0);
            
            test = 1;
        }
        if (right_sensor1 < 7 && test == 0) {
            
            fl.setPower(0.9);
            fr.setPower(0.9);
            bl.setPower(0.9);
            br.setPower(0.9);
            
            telemetry.addData("leftdistancer", left_sensor.getDistance(DistanceUnit.INCH));
            telemetry.addData("rightdistancer", right_sensor.getDistance(DistanceUnit.INCH));
            telemetry.addData("e", test);
            telemetry.update();
            
            reset();
            fl.setTargetPosition(-200);
            fr.setTargetPosition(-200);
            bl.setTargetPosition(-200);
            br.setTargetPosition(-200);
            run();
            
            reset();
            fl.setTargetPosition(-875);
            fr.setTargetPosition(875);
            bl.setTargetPosition(-875);
            br.setTargetPosition(875);
            run();
            
            reset();
            fl.setTargetPosition(-640);
            fr.setTargetPosition(-640);
            bl.setTargetPosition(-640);
            br.setTargetPosition(-640);
            run();
            
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(200);
            
            belt.setPower(1);
            rs.setPower(0);
            ls.setPower(0);
            sleep(750);
            
            belt.setPower(0);
            
            
            reset();
            fl.setTargetPosition(200);
            fr.setTargetPosition(200);
            bl.setTargetPosition(200);
            br.setTargetPosition(200);
            telemetry.addData("ticks1", fl.getTargetPosition());
            telemetry.update();
            run();
            
            reset();
            fl.setTargetPosition(-700);
            fr.setTargetPosition(-700);
            bl.setTargetPosition(-700);
            br.setTargetPosition(-700);
            run();
            
            reset();
            fl.setTargetPosition(-1900);
            fr.setTargetPosition(1900);
            bl.setTargetPosition(-1900);
            br.setTargetPosition(1900);
            run();
            
            reset();
            fl.setTargetPosition(450);
            fr.setTargetPosition(450);
            bl.setTargetPosition(450);
            br.setTargetPosition(450);
            run();
            
            reset();
            fl.setTargetPosition(-500);
            fr.setTargetPosition(500);
            bl.setTargetPosition(500);
            br.setTargetPosition(-500);
            run();
            
            reset();
            fl.setTargetPosition(320);
            fr.setTargetPosition(320);
            bl.setTargetPosition(320);
            br.setTargetPosition(320);
            run();
            
            //arm.setPosition(0.05);
            la.setPosition(0.38);
            ra.setPosition(0.87);
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(600);
            
            rs.setPower(0);
            ls.setPower(0);
            sleep(300);
            
            pincher.setPosition(0.5);
            sleep(200);
            
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(400);
            
            ls.setPower(0);
            rs.setPower(0);
            sleep(100);
            
            reset();
            fl.setTargetPosition(-450);
            fr.setTargetPosition(-450);
            bl.setTargetPosition(-450);
            br.setTargetPosition(-450);
            run();
            
            rs.setPower(0);
            ls.setPower(0);
            
            fl.setPower(0.7);
            fr.setPower(0.7);
            bl.setPower(0.7);
            br.setPower(0.7);
            
            reset();
            fl.setTargetPosition(-1000);
            fr.setTargetPosition(1000);
            bl.setTargetPosition(1000);
            br.setTargetPosition(-1000);
            run();
            
            ls.setPower(0.4);
            rs.setPower(0.4);
            //arm.setPosition(0.8);
            la.setPosition(0.12);
            ra.setPosition(0.61);
            sleep(1600);
            
            reset();
            fl.setTargetPosition(550);
            fr.setTargetPosition(550);
            bl.setTargetPosition(550);
            br.setTargetPosition(550);
            run();
            
            rs.setPower(0);
            ls.setPower(0);
            
            test = 1;
        }
        else if (left_sensor1 > 7 && right_sensor1 > 6 & test == 0){
            
            fl.setPower(0.9);
            fr.setPower(0.9);
            bl.setPower(0.9);
            br.setPower(0.9);
            
            reset();
            fl.setTargetPosition(-50);
            fr.setTargetPosition(-50);
            bl.setTargetPosition(-50);
            br.setTargetPosition(-50);
            run();
            
            telemetry.addData("leftdistancem", left_sensor.getDistance(DistanceUnit.INCH));
            telemetry.addData("rightdistanem", right_sensor.getDistance(DistanceUnit.INCH));
            telemetry.update();
            
            // reset();
            // fl.setTargetPosition(-100);
            // fr.setTargetPosition(-100);
            // bl.setTargetPosition(-100);
            // br.setTargetPosition(-100);
            // run();
            
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(200);
            
            ls.setPower(0);
            rs.setPower(0);
            belt.setPower(1);
            sleep(750);
            belt.setPower(0);
            
            reset();
            rs.setTargetPosition(160);
            ls.setTargetPosition(160);
            
            reset();
            fl.setTargetPosition(240);
            fr.setTargetPosition(240);
            bl.setTargetPosition(240);
            br.setTargetPosition(240);
            run();
            
            reset();
            fl.setTargetPosition(-780);
            fr.setTargetPosition(-780);
            bl.setTargetPosition(-780);
            br.setTargetPosition(-780);
            run();
            
            sleep(200);
            
            reset();
            fl.setTargetPosition(875);
            fr.setTargetPosition(-875);
            bl.setTargetPosition(875);
            br.setTargetPosition(-875);
            run();
            
            sleep(200);
            
            reset();
            fl.setTargetPosition(1700);
            fr.setTargetPosition(1700);
            bl.setTargetPosition(1700);
            br.setTargetPosition(1700);
            run();
            
            reset();
            fl.setTargetPosition(250);
            fr.setTargetPosition(-250);
            bl.setTargetPosition(-250);
            br.setTargetPosition(250);
            run();
            
            reset();
            fl.setTargetPosition(225);
            fr.setTargetPosition(225);
            bl.setTargetPosition(225);
            br.setTargetPosition(225);
            run();
            
            // reset();
            // fl.setTargetPosition(200);
            // fr.setTargetPosition(-200);
            // bl.setTargetPosition(-200);
            // br.setTargetPosition(200);
            // run();
            
            // reset();
            // fl.setTargetPosition(-150);
            // fr.setTargetPosition(150);
            // bl.setTargetPosition(150);
            // br.setTargetPosition(-150);
            // run();
            

            rs.setPower(0);
            ls.setPower(0);
            sleep(200);
            
            //arm.setPosition(0.05);
            la.setPosition(0.38);
            ra.setPosition(0.87);
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(600);
            
            pincher.setPosition(0.5);
            rs.setPower(0);
            ls.setPower(0);
            sleep(400);
            
            //fl.setPower(-0.3);
            //fr.setPower(0.3);
            //bl.setPower(0.3);
            //br.setPower(-0.3);
            //sleep(10000);
            
            rs.setPower(-0.5);
            ls.setPower(-0.5);
            sleep(200);
            
            rs.setPower(0);
            ls.setPower(0);
            fl.setPower(0.9);
            fr.setPower(0.9);
            bl.setPower(0.9);
            br.setPower(0.9);
            
            reset();
            fl.setTargetPosition(-600);
            fr.setTargetPosition(-600);
            bl.setTargetPosition(-600);
            br.setTargetPosition(-600);
            run();
            
            reset();
            fl.setTargetPosition(-1300);
            fr.setTargetPosition(1300);
            bl.setTargetPosition(1300);
            br.setTargetPosition(-1300);
            run();
            
            ls.setPower(0.4);
            rs.setPower(0.4);
            sleep(1600);
            
            //arm.setPosition(0.8);
            la.setPosition(0.12);
            ra.setPosition(0.61);
            
            reset();
            fl.setTargetPosition(550);
            fr.setTargetPosition(550);
            bl.setTargetPosition(550);
            br.setTargetPosition(550);
            run();
            
            test = 1;
        }

        /*while(opModeIsActive()){
            fl.setPower(0);
            fr.setPower(0);
            bl.setPower(0);
            br.setPower(0);
            wi.setPower(0);
            belt.setPower(0);
            right_sensor1 = right_sensor.getDistance(DistanceUnit.INCH);
            left_sensor1 = left_sensor.getDistance(DistanceUnit.INCH);
            telemetry.addData("leftdistance", left_sensor.getDistance(DistanceUnit.INCH));
            telemetry.addData("rightdistance", right_sensor.getDistance(DistanceUnit.INCH));
            telemetry.addData("leftdistance", left_sensor1);
            telemetry.addData("rightdistance", right_sensor1);
            //telemetry.addData("e", test);
            telemetry.update();
        }*/
    }

}
