package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "HermelaOPmode (Blocks to Java)")
public class HermelaTestCode extends LinearOpMode {

  private DcMotor backleftMotor;
  private DcMotor backrightMotor;
  private DcMotor elbow;
  private Servo claw;
  private Servo wrist;

  /**
   * This function is executed when this OpMode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    backleftMotor = hardwareMap.get(DcMotor.class, "backleftMotor");
    backrightMotor = hardwareMap.get(DcMotor.class, "backrightMotor");
    elbow = hardwareMap.get(DcMotor.class, "elbow");
    claw = hardwareMap.get(Servo.class, "claw");
    wrist = hardwareMap.get(Servo.class, "wrist");

    // Put initialization blocks here.
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      backleftMotor.setDirection(DcMotor.Direction.REVERSE);
      while (opModeIsActive()) {
        // Put loop blocks here.
        telemetry.update();
        backleftMotor.setPower(0);
        backrightMotor.setPower(0);
        if (gamepad1.dpad_up) {
          backleftMotor.setPower(1);
          backrightMotor.setPower(1);
        }
        backleftMotor.setPower(0);
        backrightMotor.setPower(0);
        if (gamepad1.dpad_down) {
          backleftMotor.setPower(-1);
          backrightMotor.setPower(-1);
        }
        backleftMotor.setPower(0);
        backrightMotor.setPower(0);
        if (gamepad1.dpad_right) {
          backleftMotor.setPower(1);
          backrightMotor.setPower(-1);
        }
        backleftMotor.setPower(0);
        backrightMotor.setPower(0);
        if (gamepad1.dpad_left) {
          backleftMotor.setPower(-1);
          backrightMotor.setPower(1);
        }
        elbow.setPower(0);
        if (gamepad1.a) {
          elbow.setPower(1);
        }
        elbow.setPower(0);
        if (gamepad1.b) {
          elbow.setPower(-1);
        }
        if (gamepad1.right_bumper) {
          claw.setPosition(0.32);
        }
        if (gamepad1.left_bumper) {
          claw.setPosition(0.47);
        }
        if (gamepad1.x) {
          wrist.setPosition(1);
        }
        if (gamepad1.y) {
          wrist.setPosition(0.35);
        }
        if (gamepad1.right_stick_button) {
        }
      }
    }
  }
}