package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

class CustomMath {
  //bounds a number between an lower and upper bound
  static double bound(double num, double lowerBound, double upperBound) {
    if (num > upperBound) {
      num = upperBound;
    
    } else if (num < lowerBound) {
      num = lowerBound;
    }
    
    return num;
  }
}

@TeleOp(name = "AsianOpMode (please work)")
public class AsianOpMode extends LinearOpMode{
  private DcMotor elbow;
  private Servo wrist;
  private Servo claw;
  
  private Servo plane;
  
  private DcMotor backrightMotor;
  private DcMotor backleftMotor;
  
  
  boolean toggle = true;
  boolean bumperPressedLastLoop;
  
  // controlled using start + A (arm movement + plane)
  private void controller1() {
    
    //launch plane
    if (gamepad1.y) {
        plane.setPosition(1);
    }
    
    //elbow movement
    elbow.setPower(0.5 * gamepad1.left_stick_y);
    
    //wrist movement
    wrist.setPosition(wrist.getPosition() - (gamepad1.right_stick_y * 0.002));
    if (gamepad1.left_bumper){
     wrist.setPosition(.71444);
     telemetry.addData("please work", "omg it works!!");
    }
    
    
    //claw movement
    if (gamepad1.right_bumper && !bumperPressedLastLoop) {
        toggle = !toggle;
        if (toggle == true) {
        claw.setPosition(0.32);
        } else {
          claw.setPosition(0.47);
        }
    }
    bumperPressedLastLoop = gamepad1.right_bumper;
  }
  
  // controlled using start + B (wheel movement)
  private void controller2() {
    if (gamepad2.right_stick_y == 0 && gamepad2.right_stick_x == 0) {
        backleftMotor.setPower( -gamepad2.left_stick_y + (gamepad2.left_stick_x * 0.75));
        backrightMotor.setPower( -gamepad2.left_stick_y - (gamepad2.left_stick_x * 0.75));
      } else {
        backleftMotor.setPower( -(gamepad2.right_stick_y * 0.25) + (gamepad2.right_stick_x * 0.75 * 0.25));
        backrightMotor.setPower( -(gamepad2.right_stick_y * 0.25) - (gamepad2.right_stick_x * 0.75 * 0.25));
      }
  }
  
  //executed when this OpMode is selected from the Driver Station
  @Override
  public void runOpMode() {
    //parts of the arm
    elbow = hardwareMap.get(DcMotor.class, "elbow");
    wrist = hardwareMap.get(Servo.class, "wrist");
    claw = hardwareMap.get(Servo.class, "claw");
    
    elbow.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    
    //plane launcher
    plane = hardwareMap.get(Servo.class, "plane");
    
    //wheels
    backrightMotor = hardwareMap.get(DcMotor.class, "backrightMotor");
    backleftMotor = hardwareMap.get(DcMotor.class, "backleftMotor");
    
    backleftMotor.setDirection(DcMotor.Direction.REVERSE);
    
    //sets the arm/plane launcher to the default position
    wrist.setPosition(0.5);
    claw.setPosition(0.4);
    plane.setPosition(0.52);
    
    waitForStart();
    
    //runs in a loop while op mode is running
    while (opModeIsActive()) {
      controller1();
      controller2();
      
      //add telemetry data
      telemetry.addData("Hand position", claw.getPosition());
      telemetry.addData("wrist.getPosition", wrist.getPosition());
      telemetry.addData("joystick y", gamepad2.left_stick_y);
      telemetry.addData("joystick x", gamepad2.left_stick_x);
      
      telemetry.update();
    }
  }
}
