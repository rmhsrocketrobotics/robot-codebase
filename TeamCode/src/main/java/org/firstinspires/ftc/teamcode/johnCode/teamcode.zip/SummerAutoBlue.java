package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.CRServo;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

@Autonomous
public class SummerAutoBlue extends LinearOpMode {
    private DistanceSensor Distance_Left;
    private DistanceSensor Distance_Right;
    private ColorSensor Color_Distance;

    @Override
    public void runOpMode() {
        DcMotor Front_Left = hardwareMap.get(DcMotor.class, "Front_Left");
        DcMotor Front_Right = hardwareMap.get(DcMotor.class, "Front_Right");
        DcMotor Back_Left = hardwareMap.get(DcMotor.class, "Back_Left");
        DcMotor Back_Right = hardwareMap.get(DcMotor.class, "Back_Right");
        Distance_Left = hardwareMap.get(DistanceSensor.class, "Distance_Left");
        Distance_Right = hardwareMap.get(DistanceSensor.class, "Distance_Right");
        Servo Claw = hardwareMap.get(Servo.class, "claw");
        DcMotor Arm = hardwareMap.get(DcMotor.class, "arm");
        DcMotor Slide = hardwareMap.get(DcMotor.class, "slide");
        CRServo Turret_Servo = hardwareMap.get(CRServo.class, "Turret_Servo");

        Front_Left.setDirection(DcMotorSimple.Direction.REVERSE);
        Back_Left.setDirection(DcMotorSimple.Direction.REVERSE);

        Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        Front_Left.setTargetPosition(0);
        Front_Right.setTargetPosition(0);
        Back_Left.setTargetPosition(0);
        Back_Right.setTargetPosition(0);

        Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        Front_Left.setPower(0.5);
        Front_Right.setPower(0.5);
        Back_Left.setPower(0.5);
        Back_Right.setPower(0.5);
        
        Claw.setPosition(1);

        waitForStart();

        double DistanceLeft = 0;
        double DistanceRight = 0;
        int test1 = 0;
        int test = 0;
        int test2 = 0;
        DistanceLeft = Distance_Left.getDistance(DistanceUnit.INCH);
        DistanceRight = Distance_Right.getDistance(DistanceUnit.INCH);
        DistanceLeft = 0;
        DistanceRight = 0;
        test = 0;
        test2 = 0;
        test1 = 0;
        
        telemetry.addData("DistanceRight", Distance_Right.getDistance(DistanceUnit.INCH));
        telemetry.addData("DistanceLeft", Distance_Left.getDistance(DistanceUnit.INCH));
        telemetry.update();

        Front_Left.setTargetPosition(670);
        Front_Right.setTargetPosition(670);
        Back_Left.setTargetPosition(670);
        Back_Right.setTargetPosition(670);
        
        while (Front_Left.isBusy()) {
            DistanceRight = Distance_Right.getDistance(DistanceUnit.INCH);
            DistanceLeft = Distance_Left.getDistance(DistanceUnit.INCH);
        }
        telemetry.update();
        
        Front_Left.setPower(0.25);
        Front_Right.setPower(0.25);
        Back_Left.setPower(0.25);
        Back_Right.setPower(0.25);
        
        Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        Front_Left.setTargetPosition(110);
        Front_Right.setTargetPosition(-110);
        Back_Left.setTargetPosition(-110);
        Back_Right.setTargetPosition(110);
        
        Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        
        while (Front_Left.isBusy()) {
            DistanceRight = Distance_Right.getDistance(DistanceUnit.INCH);
            DistanceLeft = Distance_Left.getDistance(DistanceUnit.INCH);
            telemetry.update();
        }
        telemetry.update();
        
        //Middle
        if (DistanceLeft < 3) {
            telemetry.addData("E", test);
            telemetry.update();
            
            Front_Left.setPower(0.5);
            Front_Right.setPower(0.5);
            Back_Left.setPower(0.5);
            Back_Right.setPower(0.5);
            
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

            Front_Left.setTargetPosition(-250);
            Front_Right.setTargetPosition(250);
            Back_Left.setTargetPosition(250);
            Back_Right.setTargetPosition(-250);
            
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            
            while (Front_Left.isBusy());
            
            sleep(200);
            
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

            Front_Left.setTargetPosition(2650);
            Front_Right.setTargetPosition(2650);
            Back_Left.setTargetPosition(2650);
            Back_Right.setTargetPosition(2650);
            
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            
            Turret_Servo.setPower(0.13);
            
            Arm.setPower(0);
            
            Claw.setPosition(1); 
            
            while (Front_Left.isBusy());
            
            Slide.setPower(-0.7);
            sleep(500);
            
            Turret_Servo.setPower(0);
            Arm.setPower(0);
            Slide.setPower(0);
            Claw.setPosition(0);
            
            Slide.setPower(0.7);
            
            sleep(500);
                
            Arm.setPower(0.4);
            sleep(400);
                
            Slide.setPower(0.4);
            sleep(300);
                
            Claw.setPosition(0);
            Arm.setPower(0);
            Slide.setPower(0);
            sleep(2000);
            
            Claw.setPosition(-1);
            Arm.setPower(0);
            Slide.setPower(0);
            Slide.setPower(0);
        
            Front_Left.setPower(0.3);
            Front_Right.setPower(0.3);
            Back_Left.setPower(0.3);
            Back_Right.setPower(0.3);
                
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                
            Front_Left.setTargetPosition(400);
            Front_Right.setTargetPosition(400);
            Back_Left.setTargetPosition(400);
            Back_Right.setTargetPosition(400);
                
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
                
            while (Front_Left.isBusy());
                
            sleep(300);
        
            Front_Left.setPower(0.3);
            Front_Right.setPower(0.3);
            Back_Left.setPower(0.3);
            Back_Right.setPower(0.3);
                
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                
            Front_Left.setTargetPosition(-350);
            Front_Right.setTargetPosition(-350);
            Back_Left.setTargetPosition(-350);
            Back_Right.setTargetPosition(-350);
                
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
                
            while (Front_Left.isBusy());
            
        }
        //Right
        if (DistanceRight < 3) {
            telemetry.addData("E2", test2);
            telemetry.update();
            
            Front_Left.setPower(0.5);
            Front_Right.setPower(0.5);
            Back_Left.setPower(0.5);
            Back_Right.setPower(0.5);
            
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

            Front_Left.setTargetPosition(950);
            Front_Right.setTargetPosition(-950);
            Back_Left.setTargetPosition(-950);
            Back_Right.setTargetPosition(950);
            
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            
            while (Front_Left.isBusy());
            
            sleep(200);
            
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

            Front_Left.setTargetPosition(2650);
            Front_Right.setTargetPosition(2650);
            Back_Left.setTargetPosition(2650);
            Back_Right.setTargetPosition(2650);
            
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            
            Turret_Servo.setPower(0.15);
            
            Arm.setPower(0);
            
            Claw.setPosition(1); 
            
            while (Front_Left.isBusy());
            
            Claw.setPosition(0); 
            sleep(300);
            
            Slide.setPower(-0.3);
            sleep(400);
            
            Turret_Servo.setPower(0);
            Arm.setPower(0);
            Slide.setPower(0);
            Claw.setPosition(-1);
            
            Slide.setPower(0.3);
            sleep(700);
            
            Turret_Servo.setPower(0);
            Arm.setPower(0);
            Slide.setPower(0);
            Claw.setPosition(0);
            
            Claw.setPosition(0);
            sleep(500);
                
            Arm.setPower(0.4);
            sleep(500);
                
            Slide.setPower(0.4);
            sleep(300);
                
            Claw.setPosition(-1);
            Arm.setPower(0);
            Slide.setPower(0);
            Slide.setPower(0);
        
        }
        
        
        //Left
        if (DistanceRight > 3 && DistanceLeft > 3 && test1 == 0) {
            Front_Left.setPower(0.5);
            Front_Right.setPower(0.5);
            Back_Left.setPower(0.5);
            Back_Right.setPower(0.5);
            
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

            Front_Left.setTargetPosition(-300);
            Front_Right.setTargetPosition(300);
            Back_Left.setTargetPosition(300);
            Back_Right.setTargetPosition(-300);
            
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            
            while (Front_Left.isBusy());
            
            sleep(200);
            
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

            Front_Left.setTargetPosition(3500);
            Front_Right.setTargetPosition(3500);
            Back_Left.setTargetPosition(3500);
            Back_Right.setTargetPosition(3500);
            
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            
            Turret_Servo.setPower(-0.08);
            
            Slide.setPower(0);
            
            Arm.setPower(0);
            
            Claw.setPosition(1); 
            
            while (Front_Left.isBusy());
            
            Claw.setPosition(-1); 
            sleep(500);
            
            Arm.setPower(0.6);
            sleep(250);
            
            Turret_Servo.setPower(0);
            Arm.setPower(0);
            Slide.setPower(0);
            Claw.setPosition(-1);
                
            Arm.setPower(0.4);
            sleep(400);
                
            Claw.setPosition(-1);
            Arm.setPower(0);
            Slide.setPower(0);
            
            sleep(2000);
            
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        
            Front_Left.setTargetPosition(-900);
            Front_Right.setTargetPosition(-900);
            Back_Left.setTargetPosition(-900);
            Back_Right.setTargetPosition(-900);
            
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            
            while (Front_Left.isBusy());
            
            Claw.setPosition(-1);
            Arm.setPower(0);
            Slide.setPower(0);
            Slide.setPower(0);
        
            Front_Left.setPower(0.3);
            Front_Right.setPower(0.3);
            Back_Left.setPower(0.3);
            Back_Right.setPower(0.3);
                
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                
            Front_Left.setTargetPosition(400);
            Front_Right.setTargetPosition(400);
            Back_Left.setTargetPosition(400);
            Back_Right.setTargetPosition(400);
                
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
                
            while (Front_Left.isBusy());
                
            sleep(300);
        
            Front_Left.setPower(0.3);
            Front_Right.setPower(0.3);
            Back_Left.setPower(0.3);
            Back_Right.setPower(0.3);
                
            Front_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Front_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Right.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            Back_Left.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                
            Front_Left.setTargetPosition(-350);
            Front_Right.setTargetPosition(-350);
            Back_Left.setTargetPosition(-350);
            Back_Right.setTargetPosition(-350);
                
            Front_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Front_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Left.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            Back_Right.setMode(DcMotor.RunMode.RUN_TO_POSITION);
                
            while (Front_Left.isBusy());
            
            test1 = 100;
        }
        
        // sleep(20000);

    }
}
