package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

@Autonomous(name = "AutoClose")
public class AutoClose extends LinearOpMode {

  private DcMotor backleftMotor;
  private DcMotor backrightMotor;
  private Servo wrist;
  private Servo claw;
  private Servo plane;
  private DcMotor elbow; 
  
  private ElapsedTime time;
  
  @Override
  public void runOpMode() {
    backleftMotor = hardwareMap.get(DcMotor.class, "backleftMotor");
    backrightMotor = hardwareMap.get(DcMotor.class, "backrightMotor");
    wrist = hardwareMap.get(Servo.class, "wrist");
    claw = hardwareMap.get(Servo.class, "claw");
    plane = hardwareMap.get(Servo.class,"plane");
    elbow = hardwareMap.get(DcMotor.class, "elbow");
    time  = new ElapsedTime();
    backleftMotor.setDirection(DcMotor.Direction.REVERSE);
    
    wrist.setPosition(0.65);
    plane.setPosition(0.5);
    claw.setPosition(.4); 


    waitForStart();

    DriveWithEncoder(3500, 3500, 0.5); // moves 3ish feet

    while(opModeIsActive()){
      if(time.seconds() > 18 && time.seconds() < 19){
        elbow.setPower(-.5);
      }else{
        elbow.setPower(0);
      }
      
      if(time.seconds() >= 20 && time.seconds() < 21){
          wrist.setPosition(.8); // changes these to a release position
          claw.setPosition(.6); 
        
      }
      telemetry.addData("Time in Seconds Elapsed: ", time.seconds());
      telemetry.update();
    }
  }

  private void Turn() {
    DriveWithEncoder(-30, 30, 0.5);
  }

  private void DriveWithEncoder(int Right_Target, int Left_Target, double Speed) {
    backrightMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    backleftMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    backrightMotor.setTargetPosition(Right_Target);
    backleftMotor.setTargetPosition(Left_Target);
    backrightMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    backleftMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    backrightMotor.setPower(Speed);
    backleftMotor.setPower(Speed);
    while (opModeIsActive() && backleftMotor.isBusy() && backrightMotor.isBusy()) {
      idle();
    }
  }
}